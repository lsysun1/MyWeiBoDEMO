//
//  OAuthViewController.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/22.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "OAuthViewController.h"
#import "AFNetworking.h"
#import "MyAccount.h"
#import "MyWeiBoTools.h"
#import "MyAccountTools.h"
#import "MBProgressHUD+MJ.h"
#import "MyCommon.h"

@interface OAuthViewController ()

@end

@implementation OAuthViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    //  1.添加一个UIWebView用来显示授权页面
    UIWebView *webView = [[UIWebView alloc]init];
    webView.frame = self.view.bounds;
    webView.delegate = self;
    [self.view addSubview:webView];
    
    //  2.加载授权页面
    NSURL *url = [[NSURL alloc]initWithString:MyLoginURL];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:url];
    [webView loadRequest:request];



}


#pragma mark -- UIWebView代理方法


/**
 *  在webView开始加载（发送请求）的时候调用
 *
 */
- (void)webViewDidStartLoad:(UIWebView *)webView
{
   // 显示提示框
    [MBProgressHUD showMessage:@"正在加载"];

}

/**
 *  在webView结束加载的时候调用
 *
 */
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    // 隐藏提示框
    [MBProgressHUD hideHUD];
}





/**
 *  当UIWebView发送一个Request请求之前会调用这个方法，询问代理是否可以加载这个页面
 *
 *  @param request
 *
 *  @return YES 可以加载  NO 不可以加载
 */
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    //  1.请求URL的路径
    NSString *urlStr = request.URL.absoluteString;
    
    //  2.查找code=在urlStr中的范围
    NSRange range = [urlStr rangeOfString:@"code="];
    
    //  3.如果urlStr中包含了code=
    if(range.length){
        
        //  4.截取urlStr后面的code= (经过用户授权成功)
        long loc = range.location + range.length;
        NSString *code = [urlStr substringFromIndex:loc];
        
        //5.发送POST请求给新浪，通过获取的code换取一个accessToken
        [self acessTokenWithCode:code];
        return NO;
    }
    
    return YES;
}



- (void) acessTokenWithCode:(NSString *)code
{
    //  AFNetWorking/AFN
    //  1.创建请求管理类
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];

    //  2.封装请求参数
    NSMutableDictionary *parms = [NSMutableDictionary dictionary];
    parms[@"client_id"] = MyAppKey;
    parms[@"client_secret"] = MyAppSecret;
    parms[@"grant_type"] = @"authorization_code";
    parms[@"code"] = code;
    parms[@"redirect_uri"] = MyRedirectURL ;

    
    //  3.发送求情
    [mgr POST:@"https://api.weibo.com/oauth2/access_token"
   parameters:parms
      success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        
          // 4.先将字典转为模型
          MyAccount *account = [MyAccount accountWithDict:responseObject];

          // 5.存储模型数据(归档)
          [MyAccountTools saveAccountInfo:account];
          
          // 6.登陆成功后（去新特性 OR 首页）
          [MBProgressHUD hideHUD];
          [MyWeiBoTools chooseRootController];
      }
      failure:^(AFHTTPRequestOperation *operation, NSError *error) {
          MYLog(@"请求失败!--%@",error);
          
      }];
    



}














@end
