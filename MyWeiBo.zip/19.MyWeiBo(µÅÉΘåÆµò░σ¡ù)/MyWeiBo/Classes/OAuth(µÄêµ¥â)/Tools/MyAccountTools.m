//
//  MyAccountTools.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/22.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//  账号管理工具类

#import "MyAccountTools.h"
#import "MyAccount.h"

#define MyAccountFilePath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"account.data"]

@implementation MyAccountTools
+(void)saveAccountInfo:(MyAccount *)account
{
    //存入账号
    NSDate *now = [NSDate date];
    account.expiresTime = [now dateByAddingTimeInterval:account.expires_in];
    [NSKeyedArchiver archiveRootObject:account toFile:MyAccountFilePath];
}

+(MyAccount *)GetAccount
{
    //取出账号
    MyAccount *account = [NSKeyedUnarchiver unarchiveObjectWithFile:MyAccountFilePath];

    //判断是否过期
    NSDate *now = [NSDate date];
    if([now compare:account.expiresTime] == NSOrderedAscending){
        return account;
    }else{
        return nil;
    }

//    
//    if(account.expiresTime){
//        return account;
//    }else{
//        return nil;
//    }
//    
}




@end
