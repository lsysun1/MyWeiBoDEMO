//
//  MyAccountTools.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/22.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MyAccount;
@interface MyAccountTools : NSObject


/**
 *  存储账号信息
 *
 *  @param account 需要存储的账号 
 */
+(void)saveAccountInfo:(MyAccount *)account;




+(MyAccount *)GetAccount;
@end
