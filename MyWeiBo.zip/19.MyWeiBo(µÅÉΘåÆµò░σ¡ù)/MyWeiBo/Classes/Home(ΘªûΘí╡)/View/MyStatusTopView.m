//
//  MyStatusTopView.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/30.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyStatusTopView.h"
#import "MyStatusesFrame.h"
#import "UIImageView+WebCache.h"
#import "MyStatusesModel.h"
#import "MyUser.h"
#import "MyReweetStatusView.h"
#import "MyCommon.h"


@interface MyStatusTopView()
/**  头像的View  **/
@property (nonatomic, weak) UIImageView *iconView;
/**  会员图标的View  **/
@property (nonatomic, weak) UIImageView *vipView;
/**  微博配图的View  **/
@property (nonatomic, weak) UIImageView *photoView;
/**  昵称的Label  **/
@property (nonatomic, weak) UILabel *nameLabel;
/**  时间的Label  **/
@property (nonatomic, weak) UILabel *timeLabel;
/**  来源的Label  **/
@property (nonatomic, weak) UILabel *sourceLabel;
/**  正文\微博内容的Label  **/
@property (nonatomic, weak) UILabel *contentLabel;

/**  被转发微博的的View（父控件）  **/
@property (nonatomic, weak) MyReweetStatusView *retweetView;


@end


@implementation MyStatusTopView

- (id) initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame]){
        //  1.设置图片
        self.image = [UIImage resizeImageWithName:@"timeline_card_top_background"];
        self.highlightedImage = [UIImage resizeImageWithName:@"timeline_card_top_background_highlighted"];
        
        /** 2.头像 */
        UIImageView *iconView = [[UIImageView alloc] init];
        [self addSubview:iconView];
        self.iconView = iconView;
        
        /** 3.会员图标 */
        UIImageView *vipView = [[UIImageView alloc] init];
        vipView.contentMode = UIViewContentModeCenter;
        [self addSubview:vipView];
        self.vipView = vipView;
        
        /** 4.配图 */
        UIImageView *photoView = [[UIImageView alloc] init];
        [self addSubview:photoView];
        self.photoView = photoView;
        
        /** 5.昵称 */
        UILabel *nameLabel = [[UILabel alloc] init];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = MyStatueseNameFont;
        [self addSubview:nameLabel];
        self.nameLabel = nameLabel;
        
        /** 6.时间 */
        UILabel *timeLabel = [[UILabel alloc] init];
        timeLabel.backgroundColor = [UIColor clearColor];
        timeLabel.font = MyStatueseTimeFont;
        timeLabel.textColor = MyColor(240, 140, 19);
        [self addSubview:timeLabel];
        self.timeLabel = timeLabel;
        
        /** 7.来源 */
        UILabel *sourceLabel = [[UILabel alloc] init];
        sourceLabel.backgroundColor = [UIColor clearColor];
        sourceLabel.textColor = MyColor(135, 135, 135);
        sourceLabel.font = MyStatueseSourceFont;
        [self addSubview:sourceLabel];
        self.sourceLabel = sourceLabel;
        
        /** 8.正文\内容 */
        UILabel *contentLabel = [[UILabel alloc] init];
        contentLabel.backgroundColor = [UIColor clearColor];
        contentLabel.textColor = MyColor(39, 39, 39);
        contentLabel.numberOfLines = 0;
        contentLabel.font = MyStatueseContentFont;
        [self addSubview:contentLabel];
        self.contentLabel = contentLabel;
        
        
        // 9.添加被转发微博的view
        MyReweetStatusView *retweetView = [[MyReweetStatusView alloc] init];
        [self  addSubview:retweetView];
        self.retweetView = retweetView;
        

    }
    return self;
}


- (void) setStatusFrame:(MyStatueseFrame *)statusFrame
{
    _statusFrame = statusFrame;
    
    //  1.取出模型数据
    MyStatusesModel *status = _statusFrame.statueseModel;
    MyUser *user = status.user;
    
    
    // 2.头像
    [self.iconView setImageWithURL:[NSURL URLWithString:user.profile_image_url] placeholderImage:[UIImage imageWithName:@"avatar_default_small"]];
    self.iconView.frame = self.statusFrame.iconViewFrame;
    
    // 3.昵称
    self.nameLabel.text = user.name;
    self.nameLabel.frame = self.statusFrame.nameLabelFrame;
    
    // 4.vip
    if (user.mbtype > 2) {
        self.vipView.hidden = NO;
        self.vipView.image = [UIImage imageWithName:[NSString stringWithFormat:@"common_icon_membership_level%d", user.mbrank]];
        self.vipView.frame = self.statusFrame.vipViewFrame;
        self.nameLabel.textColor = [UIColor orangeColor];
    } else {
        self.vipView.hidden = YES;
    }
    
    // 5.时间
    self.timeLabel.text = status.created_at;
    self.timeLabel.frame = self.statusFrame.timeLabelFrame;
    CGFloat timeLabelX = self.statusFrame.nameLabelFrame.origin.x;
    CGFloat timeLabelY = CGRectGetMaxY(self.statusFrame.nameLabelFrame) + MyStatueseCellBorder * 0.7;
    CGSize timeLabelSize = [status.created_at sizeWithFont:MyStatueseTimeFont];
    self.timeLabel.frame = (CGRect){{timeLabelX, timeLabelY}, timeLabelSize};
    
    // 6.来源
    self.sourceLabel.text = status.source;
    CGFloat sourceLabelX = CGRectGetMaxX(self.timeLabel.frame) + MyStatueseCellBorder;
    CGFloat sourceLabelY = timeLabelY;
    CGSize sourceLabelSize = [status.source sizeWithFont:MyStatueseSourceFont];
    self.sourceLabel.frame = (CGRect){{sourceLabelX, sourceLabelY}, sourceLabelSize};
    
    
    
    // 6.来源
    self.sourceLabel.text = status.source;
    self.sourceLabel.frame = self.statusFrame.sourceLabelFrame;
    
    // 7.正文
    self.contentLabel.text = status.text;
    self.contentLabel.frame = self.statusFrame.contentLabelFrame;
    
    // 8.配图
    if(status.thumbnail_pic){
        self.photoView.hidden = NO;
        self.photoView.frame = self.statusFrame.photoViewFrame;
        [self.photoView setImageWithURL:[NSURL URLWithString:status.thumbnail_pic] placeholderImage:[UIImage imageWithName:@"timeline_image_gif"]];
    }else{
        self.photoView.hidden = YES;
    }

    
    // 1.父控件
    MyStatusesModel *reweetStatus = status.retweeted_status;
    if (reweetStatus) {
        self.retweetView.hidden = NO;
        self.retweetView.frame = self.statusFrame.repostViewFrame;
        
        //  2.传递模型数据
        self.retweetView.statusFrame = self.statusFrame;
    } else {
        self.retweetView.hidden = YES;
    }

}









@end
