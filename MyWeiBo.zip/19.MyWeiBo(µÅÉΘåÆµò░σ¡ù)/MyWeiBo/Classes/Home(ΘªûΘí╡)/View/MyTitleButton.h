//
//  MyTitleButton.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/21.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//  首页导航栏上面的标题按钮

#import <UIKit/UIKit.h>

@interface MyTitleButton : UIButton

@end
