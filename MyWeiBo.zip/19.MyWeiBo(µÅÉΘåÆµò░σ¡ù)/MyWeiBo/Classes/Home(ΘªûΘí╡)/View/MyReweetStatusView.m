//
//  MyReweetStatusView.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/30.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyReweetStatusView.h"
#import "MyStatusesFrame.h"
#import "MyStatusesModel.h"
#import "UIImageView+WebCache.h"
#import "MyUser.h"
#import "MyCommon.h"
#import "UIImage+My.h"


@interface MyReweetStatusView()
/**  被转发微博配图的View  **/
@property (nonatomic, weak) UIImageView *retweetPhotoView;
/**  被转发微博作者昵称的Label  **/
@property (nonatomic, weak) UILabel *retweetNameLabel;
/**  被转发微博正文\内容的Label  **/
@property (nonatomic, weak) UILabel *retweetContentLabel;

@end



@implementation MyReweetStatusView

- (id)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame]){
        self.image = [UIImage resizeImageWithName:@"timeline_retweet_background" left:0.9 top:0.5];
        
        
        /** 2.被转发微博作者的昵称 */
        UILabel *retweetNameLabel = [[UILabel alloc] init];
        retweetNameLabel.backgroundColor = [UIColor clearColor];
        retweetNameLabel.font = MyRepostStatueseNameFont;
        retweetNameLabel.textColor = [UIColor blueColor];
        [self addSubview:retweetNameLabel];
        self.retweetNameLabel = retweetNameLabel;
        
        /** 3.被转发微博的正文\内容 */
        UILabel *retweetContentLabel = [[UILabel alloc] init];
        retweetContentLabel.backgroundColor = [UIColor clearColor];
        retweetContentLabel.font = MyRepostStatueseContentFont;
        retweetContentLabel.numberOfLines = 0;
        [self addSubview:retweetContentLabel];
        self.retweetContentLabel = retweetContentLabel;
        
        /** 4.被转发微博的配图 */
        UIImageView *retweetPhotoView = [[UIImageView alloc] init];
        [self addSubview:retweetPhotoView];
        self.retweetPhotoView = retweetPhotoView;
        

    }
    return self;
}

- (void)setStatusFrame:(MyStatueseFrame *)statusFrame
{
    _statusFrame = statusFrame;
    MyStatusesModel *reweetStatus = statusFrame.statueseModel.retweeted_status;
    MyUser *user = reweetStatus.user;
    
    // 1.昵称
    self.retweetNameLabel.text = [NSString stringWithFormat:@"@%@",user.name];
    self.retweetNameLabel.frame = self.statusFrame.repostNameLabelFrame;
    
    // 2.正文
    self.retweetContentLabel.text = reweetStatus.text;
    self.retweetContentLabel.frame = self.statusFrame.repostContentLabelFrame;
    
    // 3.配图
    if (reweetStatus.thumbnail_pic) {
        self.retweetPhotoView.hidden = NO;
        self.retweetPhotoView.frame = self.statusFrame.repostPhotoViewFrame;
        [self.retweetPhotoView setImageWithURL:[NSURL URLWithString:reweetStatus.thumbnail_pic] placeholderImage:[UIImage imageWithName:@"timeline_image_placeholder"]];
    } else {
        self.retweetPhotoView.hidden = YES;
    }
}


@end
