//
//  MyStatusesCell.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/26.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyStatusesCell.h"
#import "MyStatusesModel.h"
#import "MyStatusesFrame.h"
#import "MyUser.h"
#import "UIImageView+WebCache.h"
#import "MyStatusToolsBar.h"
#import "MyStatusTopView.h"
#import "MyCommon.h"

@interface MyStatusesCell()
/**  顶部的View  **/
@property (nonatomic, weak) MyStatusTopView *topView;


 


/**  微博的工具条 **/
@property (nonatomic, weak) MyStatusToolsBar *toolsBarView;



@end


@implementation MyStatusesCell

#pragma mark - 初始化

+ (instancetype) cellWithTableView:(UITableView *) tableView
{
    static NSString *ID = @"statuses";
    MyStatusesCell *cell = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    if(cell == nil){
        cell = [[MyStatusesCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
    
        // 1.添加顶部的view
        [self setupTopView];

        // 2.添加微博的工具条
        [self setupStatusesToolBar];
        
    
    }
    return self;
}


/**
 *  添加顶部的view
 */
- (void)setupTopView
{
    /** 0.设置cell选中时的背景 **/
    self.selectedBackgroundView = [[UIView alloc]init];
    self.backgroundColor = [UIColor clearColor];
    
    /** 1.顶部的view */
    MyStatusTopView *topView = [[MyStatusTopView alloc] init];
    [self.contentView addSubview:topView];
    self.topView = topView;
}





/**
 *  添加微博的工具条
 */
- (void)setupStatusesToolBar
{
    /** 1.微博的工具条 */
    MyStatusToolsBar *statusToolbar = [[MyStatusToolsBar alloc] init];
    [self.contentView addSubview:statusToolbar];
    self.toolsBarView = statusToolbar;
}



#pragma mark - 设置数据

/**
 *  传递模型数据
 */
- (void) setStatueseFrame:(MyStatueseFrame *)statueseFrame
{
    _statueseFrame = statueseFrame;
    
    // 1.设置顶部view的数据
    [self setupTopViewData];
    
    
    // 2.微博工具条的数据
    [self setuptoolSBarData];
    
}




/**
 *  原创微博
 */
- (void)setupTopViewData
{

    
    // 1.topView
    self.topView.frame = self.statueseFrame.topViewFrame;

    // 2.传递模型数据
    self.topView.statusFrame = self.statueseFrame;
    
}




/**
 *  微博工具条
 */
- (void) setuptoolSBarData
{
    self.toolsBarView.frame = self.statueseFrame.toolsBarViewFrame;
    self.toolsBarView.status = self.statueseFrame.statueseModel;
}


- (void) setFrame:(CGRect)frame
{
    frame.origin.x = MyStatusTableBorder;
    frame.origin.y += MyStatusTableBorder; 
    frame.size.width -= 2 * MyStatusTableBorder;
    frame.size.height -= MyStatusTableBorder;
    [super setFrame:frame];
}







@end
