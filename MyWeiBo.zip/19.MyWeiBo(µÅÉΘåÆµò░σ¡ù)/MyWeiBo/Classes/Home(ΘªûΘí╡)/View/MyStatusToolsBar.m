//
//  MyStatusToolsBar.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/29.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyStatusToolsBar.h"
#import "MyStatusesModel.h"


@interface MyStatusToolsBar()
@property (nonatomic, strong) NSMutableArray *btns;
@property (nonatomic, strong) NSMutableArray *divders;
@property (nonatomic, weak) UIButton *reweetBtn;
@property (nonatomic, weak) UIButton *commentBtn;
@property (nonatomic, weak) UIButton *attitudeBtn;

@end



@implementation MyStatusToolsBar


- (NSMutableArray *)btns
{
    if(_btns == nil){
        _btns = [NSMutableArray array];
    }
    return _btns;
}
- (NSMutableArray *)divders
{
    if(_divders == nil){
        _divders = [NSMutableArray array];
    }
    return _divders;
}

- (id)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame]){
        self.userInteractionEnabled = YES;
        
        //  1.设置图片
        self.image = [UIImage resizeImageWithName:@"timeline_card_bottom_background"];
        self.highlightedImage = [UIImage resizeImageWithName:@"timeline_card_bottom_background_highlighted"];
        
        //  2.添加按钮
        self.reweetBtn = [self setupBtnWithTitle:@"转发"
                          Image:@"timeline_icon_retweet"
                     Background:@"timeline_card_leftbottom_highlighted"];
        
        self.commentBtn = [self setupBtnWithTitle:@"评论"
                          Image:@"timeline_icon_comment"
                     Background:@"timeline_card_middlebottom_highlighted"];
        
        self.attitudeBtn = [self setupBtnWithTitle:@"点赞"
                          Image:@"timeline_icon_unlike"
                     Background:@"timeline_card_rightbottom_highlighted"];
        
        [self setupDivder];
        [self setupDivder];

        
        
    }
    return self;
}

/**
 *  初始化分割线
 */
- (void) setupDivder
{
    UIImageView *divder = [[UIImageView alloc]init];
    divder.image = [UIImage imageWithName:@"timeline_card_bottom_line"];
    [self addSubview:divder];
    [self.divders addObject:divder];
}



/**
 *  初始化按钮
 *
 *  @param title           按钮的title
 *  @param image           按钮的图片
 *  @param backgroundImage 按钮的背景图片（点击后显示）
 *
 *  @return 返回初始化后的按钮
 */
- (UIButton *) setupBtnWithTitle:(NSString *)title Image:(NSString *)image Background:(NSString *)backgroundImage
{
    UIButton *btn =[[UIButton alloc]init];
    [btn setImage:[UIImage imageWithName:image] forState:UIControlStateNormal];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
    btn.adjustsImageWhenHighlighted = NO;
    [btn setBackgroundImage:[UIImage resizeImageWithName:backgroundImage] forState:UIControlStateHighlighted];
    [self addSubview:btn];
    [self.btns addObject:btn];
    return btn;
}



- (void) layoutSubviews
{
    [super layoutSubviews];
    
    
    long divderCount = self.divders.count;
    CGFloat divW = 2;
    
    //  1.设置按钮的尺寸
    long btnCount = self.btns.count;
    CGFloat btnW = (self.frame.size.width - divW * divderCount) / btnCount;
    CGFloat btnH = self.frame.size.height;
    CGFloat btnY = 0;
    for(int index=0; index<btnCount ;index++){
        UIButton *btn = self.btns[index];
 
        //设置button的frame
        CGFloat btnX = index * (btnW + divW);
        btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
    }
    
    
    //  2.设置分割线的尺寸
    CGFloat divH = btnH;
    CGFloat divY = 0;
    for(int index=0; index<divderCount ;index++){
        UIButton *divder = self.divders[index];
        
        //设置button的frame
        UIButton *btn= self.btns[index];
        CGFloat divX = CGRectGetMaxX(btn.frame);
        divder.frame = CGRectMake(divX, divY, divW, divH);
    }
    
}


- (void) setStatus:(MyStatusesModel *)status{
    _status = status;
    [self setupNumbersOfBtnWithCount:status.reposts_count originalTitle:@"转发" btn:self.reweetBtn];
    [self setupNumbersOfBtnWithCount:status.comments_count originalTitle:@"评论" btn:self.commentBtn];
    [self setupNumbersOfBtnWithCount:status.attitudes_count originalTitle:@"喜欢" btn:self.attitudeBtn];
}

/**
 *  设置按钮的显示标题
 *
 *  @param num           转发数，评论数
 *  @param title         标题
 *  @param originalTitle 原始标题
 *  @param btn           具体哪个按钮
 */
- (void) setupNumbersOfBtnWithCount:(int)count originalTitle:(NSString *) originalTitle btn:(UIButton *)btn
{
    if(count){
        NSString *title =nil;
        if(count <= 10000){ //1W以下
            title = [NSString stringWithFormat:@"%d",count];
        }else{//已经超过1W
            double countDouble = count / 10000.0;
            title = [NSString stringWithFormat:@"%.1f万",countDouble];
            title = [title stringByReplacingOccurrencesOfString:@".0" withString:@""];
        }
        [btn setTitle:title forState:UIControlStateNormal];
    }else{
        [btn setTitle:originalTitle forState:UIControlStateNormal];
    }
}














@end
