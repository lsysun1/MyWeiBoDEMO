//
//  MyStatusesModel.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/25.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyStatusesModel.h"
#import "MyUser.h"
#import "NSDate+My.h"

@implementation MyStatusesModel

- (NSString *)created_at
{
    //  1.获得微博的发送时间
    NSDateFormatter *fmt = [[NSDateFormatter alloc]init];
    fmt.dateFormat = @"EEE MMM dd HH:mm:ss Z yyyy";
    fmt.locale = [[NSLocale alloc]initWithLocaleIdentifier:@"en_US"];
    NSDate *createDate = [fmt dateFromString:_created_at];

    
    //  2.判断 微博发送时间 和 现在时间的差距
    if([createDate isToday]){   //今天
        if([createDate deltaWithNow].hour >= 1){
            return [NSString stringWithFormat:@"%ld小时之前",(long)[createDate deltaWithNow].hour];
        }else if ([createDate deltaWithNow].minute >= 1){
            return [NSString stringWithFormat:@"%ld分钟之前",(long)[createDate deltaWithNow].minute];
        }else{
            return @"刚刚";
        }
    }else if ([createDate isYeaterday]){   //昨天
        fmt.dateFormat = @"昨天 HH:MM";
        return [fmt stringFromDate:createDate];
    }else if ([createDate isThisYear]){    //今年
        fmt.dateFormat = @"MM-dd HH:MM";
        return [fmt stringFromDate:createDate];
    }else{  //非今年
        fmt.dateFormat = @"yyyy-MM-dd HH:MM";
        return [fmt stringFromDate:createDate];
    }

}


- (void) setSource:(NSString *)source
{
    int loc = (int)[source rangeOfString:@">"].location + 1;
    int length = (int)[source rangeOfString:@"</"].location - loc;
    _source = [NSString stringWithFormat:@"来自%@",[source substringWithRange:NSMakeRange(loc,length)]];
}










@end
