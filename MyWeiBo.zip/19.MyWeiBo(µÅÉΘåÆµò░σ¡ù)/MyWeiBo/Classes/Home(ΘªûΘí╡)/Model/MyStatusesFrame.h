//
//  MyStatusesFrame.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/26.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import <Foundation/Foundation.h>


@class MyStatusesModel;

@interface MyStatueseFrame : NSObject

@property (nonatomic, strong) MyStatusesModel *statueseModel;


/**  顶部的View  **/
@property (nonatomic, assign, readonly) CGRect topViewFrame;
/**  头像的View  **/
@property (nonatomic, assign, readonly) CGRect iconViewFrame;
/**  会员图标的View  **/
@property (nonatomic, assign, readonly) CGRect vipViewFrame;
/**  微博配图的View  **/
@property (nonatomic, assign, readonly) CGRect photoViewFrame;
/**  昵称的Label  **/
@property (nonatomic, assign, readonly) CGRect nameLabelFrame;
/**  时间的Label  **/
@property (nonatomic, assign, readonly) CGRect timeLabelFrame;
/**  来源的Label  **/
@property (nonatomic, assign, readonly) CGRect sourceLabelFrame;
/**  正文\微博内容的Label  **/
@property (nonatomic, assign, readonly) CGRect contentLabelFrame;


/**  被转发微博的的View（父控件）  **/
@property (nonatomic, assign, readonly) CGRect repostViewFrame;
/**  被转发微博配图的View  **/
@property (nonatomic, assign, readonly) CGRect repostPhotoViewFrame;
/**  被转发微博作者昵称的Label  **/
@property (nonatomic, assign, readonly) CGRect repostNameLabelFrame;
/**  被转发微博正文\内容的Label  **/
@property (nonatomic, assign, readonly) CGRect repostContentLabelFrame;



/**  微博的工具条 **/
@property (nonatomic, assign, readonly) CGRect toolsBarViewFrame;


/**  cell的高度 **/
@property (nonatomic, assign, readonly) CGFloat cellHeight;


@end
