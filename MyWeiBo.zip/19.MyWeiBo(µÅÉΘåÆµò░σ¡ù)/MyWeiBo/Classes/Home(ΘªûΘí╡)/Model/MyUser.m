//
//  MyUser.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/25.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyUser.h"

@implementation MyUser


//+ (instancetype) userWithDict :(NSDictionary *) dict
//{
//    return [[self alloc]initWithDict:dict];
//}
//- (instancetype) initWithDict :(NSDictionary *) dict
//{
//    if(self = [super init]){
//        self.user_ID = dict[@"idstr"];
//        self.name = dict[@"name"];
//        self.profile_image_url = dict[@"profile_image_url"];
//    }
//    return self;
//}



@end
