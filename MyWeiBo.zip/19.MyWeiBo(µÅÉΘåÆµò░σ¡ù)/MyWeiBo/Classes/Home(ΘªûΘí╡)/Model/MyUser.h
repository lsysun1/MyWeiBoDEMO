//
//  MyUser.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/25.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//  微博作者的数据模型

#import <Foundation/Foundation.h>

@interface MyUser : NSObject
/**
 *  作者ID
 */
@property (nonatomic, copy) NSString *user_ID;
/**
 *  作者名
 */
@property (nonatomic, copy) NSString *name;
/**
 *  作者头像url
 */
@property (nonatomic, copy) NSString *profile_image_url;

/**  
    会员等级
 **/
@property (nonatomic, assign) int mbrank;

/**
    分类如果mbtype > 2那么就是会员
 **/
@property (nonatomic, assign) int mbtype;

@end
