//
//  MyStatusesFrame.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/26.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyStatusesFrame.h"
#import "MyStatusesModel.h"
#import "MyUser.h"
#import "MyCommon.h"

@implementation MyStatueseFrame

/**
 *  获得微博模型数据之后，根据微博数据结算所有子控件的frame
 */
- (void)setStatueseModel:(MyStatusesModel *)statueseModel
{
    _statueseModel = statueseModel;
    
    // cell的宽度
    CGFloat cellW = [UIScreen mainScreen].bounds.size.width - 2 * MyStatusTableBorder;
    
    // 1.topView
    CGFloat topViewW = cellW;
    CGFloat topViewX = 0;
    CGFloat topViewY = 0;
    CGFloat topViewH = 0;   //在最后面重新赋值
    
    // 2.头像
    CGFloat iconViewWH = 35;
    CGFloat iconViewX = MyStatueseCellBorder;
    CGFloat iconViewY = MyStatueseCellBorder;
    _iconViewFrame = CGRectMake(iconViewX, iconViewY, iconViewWH, iconViewWH);
    
    // 3.昵称
    CGFloat nameLabelX = CGRectGetMaxX(_iconViewFrame) + MyStatueseCellBorder;
    CGFloat nameLabelY = iconViewY;
    CGSize nameLabelSize = [_statueseModel.user.name sizeWithFont:MyStatueseNameFont];
    _nameLabelFrame = (CGRect){{nameLabelX, nameLabelY}, nameLabelSize};
    
    // 4.会员图标
    if (_statueseModel.user.mbtype > 2) {
        CGFloat vipViewW = 14;
        CGFloat vipViewH = nameLabelSize.height;
        CGFloat vipViewX = CGRectGetMaxX(_nameLabelFrame) + MyStatueseCellBorder;
        CGFloat vipViewY = nameLabelY;
        _vipViewFrame = CGRectMake(vipViewX, vipViewY, vipViewW, vipViewH);
    }
    
    // 5.时间
    CGFloat timeLabelX = nameLabelX;
    CGFloat timeLabelY = CGRectGetMaxY(_nameLabelFrame) + MyStatueseCellBorder * 0.7;
    CGSize timeLabelSize = [_statueseModel.created_at sizeWithFont:MyStatueseTimeFont];
    _timeLabelFrame = (CGRect){{timeLabelX, timeLabelY}, timeLabelSize};
    
    // 6.来源
    CGFloat sourceLabelX = CGRectGetMaxX(_timeLabelFrame) + MyStatueseCellBorder;
    CGFloat sourceLabelY = timeLabelY;
    CGSize sourceLabelSize = [_statueseModel.source sizeWithFont:MyStatueseSourceFont];
    _sourceLabelFrame = (CGRect){{sourceLabelX, sourceLabelY}, sourceLabelSize};
    
    // 7.微博正文内容
    CGFloat contentLabelX = iconViewX;
    CGFloat contentLabelY = MAX(CGRectGetMaxY(_timeLabelFrame), CGRectGetMaxY(_iconViewFrame)) + MyStatueseCellBorder * 0.5;
    CGFloat contentLabelMaxW = topViewW - 2 * MyStatueseCellBorder;
    CGSize contentLabelSize = [_statueseModel.text sizeWithFont:MyStatueseContentFont constrainedToSize:CGSizeMake(contentLabelMaxW, MAXFLOAT)];
    _contentLabelFrame = (CGRect){{contentLabelX, contentLabelY}, contentLabelSize};
    
    
    // 8.微博配图
    if(statueseModel.thumbnail_pic){
        CGFloat photoViewWH = 100;
        CGFloat photoViewX = contentLabelX;
        CGFloat photoViewY = CGRectGetMaxY(_contentLabelFrame) + MyStatueseCellBorder;
        _photoViewFrame = CGRectMake(photoViewX, photoViewY, photoViewWH, photoViewWH);
    }
    
    // 9.被转发微博
    if (statueseModel.retweeted_status) {
        CGFloat retweetViewW = contentLabelMaxW;
        CGFloat retweetViewX = contentLabelX;
        CGFloat retweetViewY = CGRectGetMaxY(_contentLabelFrame) + MyStatueseCellBorder * 0.5;
        CGFloat retweetViewH = 0;
        
        // 10.被转发微博的昵称
        CGFloat retweetNameLabelX = MyStatueseCellBorder;
        CGFloat retweetNameLabelY = MyStatueseCellBorder;
        NSString *name = [NSString stringWithFormat:@"@%@",statueseModel.retweeted_status.user.name];
        CGSize retweetNameLabelSize = [name sizeWithFont:MyRepostStatueseNameFont];
        _repostNameLabelFrame = (CGRect){{retweetNameLabelX, retweetNameLabelY}, retweetNameLabelSize};
        
        // 11.被转发微博的正文
        CGFloat retweetContentLabelX = retweetNameLabelX;
        CGFloat retweetContentLabelY = CGRectGetMaxY(_repostNameLabelFrame) + MyStatueseCellBorder * 0.5;
        CGFloat retweetContentLabelMaxW = retweetViewW - 2 * MyStatueseCellBorder;
        CGSize retweetContentLabelSize = [statueseModel.retweeted_status.text sizeWithFont:MyRepostStatueseContentFont constrainedToSize:CGSizeMake(retweetContentLabelMaxW, MAXFLOAT)];
        _repostContentLabelFrame = (CGRect){{retweetContentLabelX, retweetContentLabelY}, retweetContentLabelSize};
        
        // 12.被转发微博的配图
        if(statueseModel.retweeted_status.thumbnail_pic) {
            CGFloat retweetPhotoViewWH = 100;
            CGFloat retweetPhotoViewX = retweetContentLabelX;
            CGFloat retweetPhotoViewY = CGRectGetMaxY(_repostContentLabelFrame) + MyStatueseCellBorder;
            _repostPhotoViewFrame = CGRectMake(retweetPhotoViewX, retweetPhotoViewY, retweetPhotoViewWH, retweetPhotoViewWH);
            
            retweetViewH = CGRectGetMaxY(_repostPhotoViewFrame);
        } else { // 没有配图
            retweetViewH = CGRectGetMaxY(_repostContentLabelFrame);
        }
        retweetViewH += MyStatueseCellBorder;
        _repostViewFrame = CGRectMake(retweetViewX, retweetViewY, retweetViewW, retweetViewH);
        
        // 有转发微博时topViewH
        topViewH = CGRectGetMaxY(_repostViewFrame);
    } else { // 没有转发微博
        if (statueseModel.thumbnail_pic) { // 有图
            topViewH = CGRectGetMaxY(_photoViewFrame);
        } else { // 无图
            topViewH = CGRectGetMaxY(_contentLabelFrame);
        }
    }
    topViewH += MyStatueseCellBorder;
    _topViewFrame = CGRectMake(topViewX, topViewY, topViewW, topViewH);
    
    
    // 14.工具条
    CGFloat toolsBarX = topViewX;
    CGFloat toolsBarY = CGRectGetMaxY(_topViewFrame);
    CGFloat toolsBarW = topViewW;
    CGFloat toolsBarH = 35;
    _toolsBarViewFrame = CGRectMake(toolsBarX, toolsBarY, toolsBarW, toolsBarH);
    
    // 13.cell的高度
    _cellHeight = CGRectGetMaxY(_toolsBarViewFrame) + MyStatusTableBorder;
    
}


















@end
