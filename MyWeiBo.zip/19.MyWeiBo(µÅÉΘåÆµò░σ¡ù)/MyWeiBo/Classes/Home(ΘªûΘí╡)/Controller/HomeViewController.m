//
//  HomeViewController.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/19.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "HomeViewController.h"
#import "UIBarButtonItem+My.h"
#import "MyTitleButton.h"
#import "AFNetworking.h"
#import "MyAccountTools.h"
#import "MyAccount.h"
#import "UIImageView+WebCache.h"
#import "MyStatusesModel.h"
#import "MyUser.h"
#import "MJExtension.h"
#import "MyStatusesFrame.h"
#import "MyStatusesCell.h"
#import "MJRefresh.h"

#define MyTitleButtonTagUp 1
#define MyTitleButtonTagDown 0

@interface HomeViewController ()
@property (nonatomic, strong) UIButton *titleButton;
@property (nonatomic, strong) NSMutableArray *statusesFrame;
@property (nonatomic, strong) UIRefreshControl *headRefresh;

@end

@implementation HomeViewController


- (NSMutableArray *)statusesFrame
{
    if(_statusesFrame == nil){
        _statusesFrame = [NSMutableArray array];
    
    }
    return _statusesFrame;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    
    //  0.集成刷新空间
    [self setupRefreshView];
    
    //  1.设置导航栏
    [self setupNavBar];
    
    //  2.设置标题用户昵称
    [self setupUserData];
    

}


- (void) setupUserData
{
    //  0.只要下拉刷新就清除badgValue
    self.tabBarItem.badgeValue = nil;
    
    //  1.创建AFN请求管理对象
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    //  2.封装请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [MyAccountTools GetAccount].access_token;
    params[@"uid"] = @([MyAccountTools GetAccount].uid);

    //  3.发送请求
    [mgr GET:@"https://api.weibo.com/2/users/show.json"
  parameters:params
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
      // 数据转模型
         MyUser *user = [MyUser objectWithKeyValues:responseObject];
         [self.titleButton setTitle:user.name forState:UIControlStateNormal];
         
      // 保存昵称
         MyAccount *myAcount = [MyAccountTools GetAccount];
         myAcount.name = user.name;
         [MyAccountTools saveAccountInfo:myAcount];
         
         
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];

}





- (void) setupRefreshView
{
    //  下拉刷新
    //  创建一个UIRefreshControl控件对象
    UIRefreshControl *refresh = [[UIRefreshControl alloc]init];
    _headRefresh = refresh;
    //  添加一个方法用来监听刷新控件的状态改变
    [refresh addTarget:self action:@selector(refreshControlStateChange:) forControlEvents:UIControlEventValueChanged];
    //  将UIRefreshControl添加到当前控制器的View上面去
    [self.view addSubview:refresh];
    
    //  自动进入刷新状态,不会触发上面的监听方法.
    //  只有手动进入刷新状态,才会调用监听方法.
    [refresh beginRefreshing];
    
    //  上拉刷新
    [self.tableView addFooterWithCallback:^{
        //  1.创建AFN请求管理对象
        AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
        //  2.封装请求参数
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
        params[@"access_token"] = [MyAccountTools GetAccount].access_token;
        params[@"count"] = @5;
        if(self.statusesFrame.count){
            MyStatueseFrame *statusFrame = [self.statusesFrame lastObject];
            //  max_id  若指定此参数，则返回ID比since_id大的微博（即比since_id时间晚的微博），默认为0
            long long lastId = [statusFrame.statueseModel.idstr longLongValue] - 1 ;
            params[@"max_id"] = @(lastId);
        }
        //  3.发送请求
        [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json"
      parameters:params
         success:^(AFHTTPRequestOperation *operation, id responseObject) {
             //将字典数组转为模型数组(里面放的就是MyStatusesModel模型)
             NSArray *statusesArray = [MyStatusesModel objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
             //创建frame模型对象
             NSMutableArray *statusesFrameArray = [NSMutableArray array];
             for (MyStatusesModel *statusesModel in statusesArray){
                 MyStatueseFrame *statusesFrame =  [[MyStatueseFrame alloc]init];
                 //传递微博模型数据
                 statusesFrame.statueseModel = statusesModel;
                 [statusesFrameArray addObject:statusesFrame];
             }

             // 添加新数据到旧数据的后面
             [self.statusesFrame addObjectsFromArray:statusesFrameArray];
             
             // 刷新表格
             [self.tableView reloadData];
             [self.tableView footerEndRefreshing];

         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [self.tableView footerEndRefreshing];
         }
         ];
    }];
    
    [self refreshControlStateChange:refresh];
}



/**
 *  通过这个方法来实现向下拉动表格刷新数据的功能
 *
 *  @param refresh 传入这个控件,方便监控状态.
 */
- (void) refreshControlStateChange:(UIRefreshControl *)refresh
{
    //  1.创建AFN请求管理对象
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    //  2.封装请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [MyAccountTools GetAccount].access_token;
    params[@"count"] = @5;
    if(self.statusesFrame.count){
        MyStatueseFrame *statusFrame = self.statusesFrame[0];
        //  since_id  若指定此参数，则返回ID比since_id大的微博（即比since_id时间晚的微博），默认为0
            params[@"since_id"] = statusFrame.statueseModel.idstr;
    }
    //  3.发送请求
    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json"
  parameters:params
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         //将字典数组转为模型数组(里面放的就是MyStatusesModel模型)
         NSArray *statusesArray = [MyStatusesModel objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
         //创建frame模型对象
         NSMutableArray *statusesFrameArray = [NSMutableArray array];
         for (MyStatusesModel *statusesModel in statusesArray){
             MyStatueseFrame *statusesFrame =  [[MyStatueseFrame alloc]init];
             //传递微博模型数据
             statusesFrame.statueseModel = statusesModel;
             [statusesFrameArray addObject:statusesFrame];
         }
         // 将最新的微博数据加载到旧数据的前面
         // 旧数据:self.statusesFrame
         // 新数据:statusesFrameArray
         // self.statusesFrame = statusesFrameArray;       //如果直接这样赋值,那么新的数据就会覆盖旧的数据
         // 就先创建一个NSMutableArray用来当做temp
         NSMutableArray *tempArray = [NSMutableArray array];
         [tempArray addObjectsFromArray:statusesFrameArray];
         [tempArray addObjectsFromArray:self.statusesFrame];
         self.statusesFrame = tempArray ;
         
         // 这样还是会有一个问题:
         // 如果我们已经获取了数据.但是我们在其他客户端上删除了某一条微博
         // 我们下拉表格,我们已经删除的微博还是会继续出现在我们的应用上面
         // 因为是直接将以前的旧数据传递给tempArray
         // 就算旧数据已经被更改了,由于之间的数据是保存在我们的应用当中
         // 所以它还是会在我们的应用上面
         
         
          // 刷新表格
         [self.tableView reloadData];
         //  让refresh空间停止刷新
         [self showNewStatusCount:statusesArray.count];
         [refresh endRefreshing];
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [refresh endRefreshing];
     }
     ];
}



- (void) showNewStatusCount:(long)count
{
    //  1.创建按钮
    UIButton *btn = [[UIButton alloc]init];
    [self.navigationController.view insertSubview:btn belowSubview:self.navigationController.navigationBar];

    //  2.设置图片和文字
    btn.userInteractionEnabled = NO;
    [btn setBackgroundImage:[UIImage resizeImageWithName:@"timeline_new_status_background"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    if(count){
        NSString *title = [NSString stringWithFormat:@"您有%ld条新微博",count];
        [btn setTitle:title forState:UIControlStateNormal];
    }else{
        [btn setTitle:@"您已经没有新的微博" forState:UIControlStateNormal];
    }
    
    //  3.设置按钮的frame
    CGFloat btnX = 0;
    CGFloat btnW = self.view.frame.size.width;
    CGFloat btnH = 30;
    CGFloat btnY = 64 - btnH;
    btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
    
    //  4.通过动画来展示这个按钮
    [UIView animateWithDuration:1.0 animations:^{
        btn.transform = CGAffineTransformMakeTranslation(0, btnH + 2);
    }completion:^(BOOL finished) {
        [UIView animateKeyframesWithDuration:1.0 delay:1.0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
            btn.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            [btn removeFromSuperview];
        }];
    }
     ];
}





- (void) setupNavBar
{
 
    //  左边按钮
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem target:self
                                                       itemWithIcon:@"navigationbar_friendsearch"
                                                           HighIcon:@"navigationbar_friendsearch_highlighted"
                                                             action:@selector(findFriend)];
    //  右边按钮
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem target:self
                                                        itemWithIcon:@"navigationbar_pop"
                                                            HighIcon:@"navigationbar_pop_highlighted"
                                                              action:@selector(pop)];
    
    //  中间按钮
    MyTitleButton *titleButton = [[MyTitleButton alloc]init];
    [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
    titleButton.frame = CGRectMake(0, 0, 0, 40);
    if([MyAccountTools GetAccount].name){
        [titleButton setTitle:[MyAccountTools GetAccount].name forState:UIControlStateNormal];
    }else{
        [titleButton setTitle:@"首页" forState:UIControlStateNormal];
    }
    [titleButton addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
    titleButton.tag = MyTitleButtonTagDown;
    self.navigationItem.titleView = titleButton;
    self.titleButton = titleButton;
    
    self.tableView.backgroundColor = MyColor(226, 226, 226);
    //self.tableView.contentInset = UIEdgeInsetsMake(0, 0,MyStatusTableBorder, 0);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

}






- (void)titleClick:(MyTitleButton *)titleButton
{
    if(titleButton.tag == MyTitleButtonTagDown){
        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_up"] forState:UIControlStateNormal];
        titleButton.tag = MyTitleButtonTagUp;
    }else{
        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
        titleButton.tag = MyTitleButtonTagDown;
    }
 
}


- (void)findFriend
{

}


- (void)pop
{


}


#pragma mark - Table view data source

//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//    // Return the number of sections.
//    return 0;
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return self.statusesFrame.count;
}


//  重写cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //1.创建cell
    MyStatusesCell *cell = [MyStatusesCell cellWithTableView:tableView];
    
    //2.传递模型数据
    cell.statueseFrame = self.statusesFrame[indexPath.row];
    return cell;
}



#pragma mark 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyStatueseFrame *statusesFrame = self.statusesFrame[indexPath.row];
    return statusesFrame.cellHeight;

}






@end
