//
//  MyBadgeButton.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/21.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyBadgeButton.h"
#import "UIImage+My.h"

@implementation MyBadgeButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self){
        self.userInteractionEnabled = NO;
        self.hidden = YES;
        [self setBackgroundImage:[UIImage resizeImageWithName:@"main_badge"] forState:UIControlStateNormal];
        self .titleLabel.font = [UIFont systemFontOfSize:11];
    }
    return self;
}


- (void)setBadgeValue:(NSString *)badgeValue
{
    _badgeValue = [badgeValue copy];
    
    if(badgeValue && [badgeValue intValue] != 0){
        self.hidden = NO;
        // 设置文字
            [self setTitle:badgeValue forState:UIControlStateNormal];
        
        //
        CGRect frame = self.frame;
        // 设置badgeButton尺寸
        CGFloat badgeH = self.currentBackgroundImage.size.height;
        CGFloat badgeW = self.currentBackgroundImage.size.width;
        if(badgeValue.length > 1){
            // badgeButton里面文字的尺寸
            CGSize badgeVauleSize = [badgeValue sizeWithFont:self.titleLabel.font];
            badgeW = badgeVauleSize.width + 10;
        }
        frame.size.height = badgeH;
        frame.size.width = badgeW;
        self.frame = frame;
    }else{
        self.hidden = YES;
    }



}




@end
