//
//  MyTabBar.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/19.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyTabBar.h"
#import "MyTabBarButton.h"


@interface MyTabBar()
@property (nonatomic,strong) NSMutableArray *tabBarButtons;
@property (nonatomic,weak) MyTabBarButton *selectbutton;
@property (nonatomic,weak) UIButton *plusButton;
@end


@implementation MyTabBar



- (NSMutableArray *)tabBarButtons
{
    if(_tabBarButtons == nil){
        _tabBarButtons = [NSMutableArray array];
    }
    return _tabBarButtons;
}





- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        if(!iOS7){
            self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithName:@"tabbar_background.png"]];
        }
    
        //  添加一个加号按钮
        UIButton *plusButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [plusButton setBackgroundImage:[UIImage imageWithName:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [plusButton setBackgroundImage:[UIImage imageWithName:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        [plusButton setImage:[UIImage imageWithName:@"tabbar_compose_icon_add"] forState:UIControlStateNormal];
        [plusButton setImage:[UIImage imageWithName:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];
        plusButton.bounds = CGRectMake(0, 0, plusButton.currentBackgroundImage.size.width, plusButton.currentBackgroundImage.size.height);
        [plusButton addTarget:self action:@selector(plusButtonDidClick) forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:plusButton];
        self.plusButton = plusButton;
        
        
        
        
        
    }
    return self;
}




/**
 *  这里需要做的是,点击这个方法modal出一个控制器.由于只有控制器才能监听控制器方法
 *  这里的MyTabBar是一个View,所以不能直接在这里写弹出窗口的代码
 *  我们只能点击这个plusButton按钮来通知外面的控制器,弹出我们需要的控制器
 *  用代理来做
 */
- (void)plusButtonDidClick{
    //  判断代理是不是实现了tabBarDidClickPlusButton:这个方法；
    if([self.delegate respondsToSelector:@selector(tabBarDidClickPlusButton:)]){
        //告诉代理我们点击了这个加号按钮
        [self.delegate tabBarDidClickPlusButton:self];
    }
}



- (void) addTabBarButtonWithItem:(UITabBarItem *)item
{
    //1.创建按钮
    MyTabBarButton *button = [[MyTabBarButton alloc]init];
    [self addSubview:button];
    
    //2.添加按钮到tabBarButtons数组中
    [self.tabBarButtons addObject:button];
    
    //3.设置数据
    button.item = item;

    //4.监听按钮点击
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchDown];
    
    //4.默认选中第0个按钮
    if(self.tabBarButtons.count == 1){
        [self buttonClick:button];
    }
}


/**
 *  监听按钮点击
 *
 */
- (void) buttonClick:(MyTabBarButton *)button
{
    //1.通知道理
    if([self.delegate respondsToSelector:@selector(tabBar:didSelectedButtonFrom:To:)]){
        [self.delegate tabBar:self didSelectedButtonFrom:self.selectbutton.tag To:button.tag];
    }
    
    //2.设置按钮的状态
    self.selectbutton.selected = NO;
    button.selected = YES;
    self.selectbutton = button;
}





- (void)layoutSubviews
{
    [super layoutSubviews];
    
    
    CGFloat tabBarH = self.frame.size.height;
    CGFloat tabBarW = self.frame.size.width;
    
    
    //  调整加号按钮的位置
    self.plusButton.center = CGPointMake(tabBarW * 0.5, tabBarH * 0.5);
    
    
    
    //  按钮的frame
    CGFloat buttonW = tabBarW / self.subviews.count;
    CGFloat buttonH = tabBarH;
    CGFloat buttonY = 0;
    for(int index = 0; index < self.tabBarButtons.count ; index ++){
        //1.取出按钮
        UIButton *butoon = self.tabBarButtons[index];
        
        //2.设置按钮的frame
        CGFloat buttonX = index * buttonW;
        if(index > 1){
            buttonX += buttonW;
        }
        butoon.frame = CGRectMake(buttonX, buttonY, buttonW, buttonH);
        
        //3.绑定tag
        butoon.tag = index;
    }

}










@end
