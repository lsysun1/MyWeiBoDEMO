//
//  MyTabBar.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/19.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyTabBar;



@protocol MyTabBarDelegate <NSObject>
@optional
- (void) tabBar:(MyTabBar *)tabBar didSelectedButtonFrom:(long int)from To:(long int)to;
- (void) tabBarDidClickPlusButton:(MyTabBar *)tabBar;

@end



@interface MyTabBar : UIView
- (void) addTabBarButtonWithItem:(UITabBarItem *)item;
@property(nonatomic,weak) id <MyTabBarDelegate> delegate;

@end
