//
//  MyNavgationViewController.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/21.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "MyNavgationViewController.h"
#import "UIImage+My.h"

@interface MyNavgationViewController ()

@end

@implementation MyNavgationViewController




/**
 *  第一次使用这个类的时候会调用这个方法。（只会调用一次）
 */
+ (void)initialize
{
    //1.设置导航栏主题
    [self setupNavBarTheme];
    
    //2.设置导航栏按钮主题
    [self setupBarButtonItemTheme];
    
}




/**
 *  设置导航栏主题
 */
+ (void)setupNavBarTheme{
    //  取出appearance对象
    UINavigationBar *navBar = [UINavigationBar appearance];
    if(!iOS7){
        //  设置背景
        [navBar setBackgroundImage:[UIImage imageWithName:@"navigationbar_background"] forBarMetrics:UIBarMetricsDefault];
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleBlackOpaque;
        //  设置标题文字属性
        NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
        textAttrs[UITextAttributeTextColor] = [UIColor blackColor];
        textAttrs[UITextAttributeTextShadowOffset] = [NSValue valueWithUIOffset:UIOffsetZero];
        textAttrs[UITextAttributeFont] = [UIFont boldSystemFontOfSize:19];
        [navBar setTitleTextAttributes:textAttrs];
    }

}


/**
 *  设置导航栏按钮主题
 */
+ (void)setupBarButtonItemTheme{
    UIBarButtonItem *item = [UIBarButtonItem appearance];
    if(!iOS7){
    //  设置背景
    [item setBackButtonBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [item setBackButtonBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background_pushed"] forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    [item setBackButtonBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background_disable"] forState:UIControlStateDisabled barMetrics:UIBarMetricsDefault];
    }
    //  设置标题文字属性
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[UITextAttributeTextColor] = iOS7 ? [UIColor orangeColor] : [UIColor grayColor];
    textAttrs[UITextAttributeTextShadowOffset] = [NSValue valueWithUIOffset:UIOffsetZero];
    textAttrs[UITextAttributeFont] = [UIFont boldSystemFontOfSize:iOS7 ? 14 : 11];
    [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:textAttrs forState:UIControlStateHighlighted];
    
    NSMutableDictionary *disableTextAttrs = [NSMutableDictionary dictionary];
    disableTextAttrs[UITextAttributeTextColor] =  [UIColor grayColor];
    [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateDisabled];

    
    
    

}



- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if(self.viewControllers.count > 0){
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:YES];
}



@end
