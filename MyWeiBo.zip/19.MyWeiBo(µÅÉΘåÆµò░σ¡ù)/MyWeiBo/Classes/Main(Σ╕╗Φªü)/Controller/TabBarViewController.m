//
//  TabBarViewController.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/19.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "TabBarViewController.h"
#import "HomeViewController.h"
#import "MessageViewController.h"
#import "DiscoverViewController.h"
#import "MeViewController.h"
#import "MyTabBar.h"
#import "MyNavgationViewController.h"
#import "UIImage+My.h"
#import "MyComposeViewController.h"
#import "AFNetworking.h"
#import "MyUnreadModel.h"
#import "MyAccountTools.h"
#import "MyAccount.h"
#import "MJExtension.h"

@interface TabBarViewController () <MyTabBarDelegate>

/**
 *  自定义TabBar
 */
@property (nonatomic,weak) MyTabBar *customTabBar;
@property (nonatomic,strong) HomeViewController *home;

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //初始化TabBar
    [self setupTabBar];
    
    //初始化所有子控制器
    [self setupAllChildViewController];
    
    //定时检查未读数
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(checkUnreadCount) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}


- (void)checkUnreadCount
{
    //  1.创建AFN请求管理对象
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    //  2.封装请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [MyAccountTools GetAccount].access_token;
    params[@"uid"] = @([MyAccountTools GetAccount].uid);
    
    //  3.发送请求
    [mgr GET:@"https://rm.api.weibo.com/2/remind/unread_count.json"
  parameters:params
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         // 数据转模型
         MyUnreadModel *unread = [MyUnreadModel objectWithKeyValues:responseObject];
         
         //设置首页未读消息数
         self.home.tabBarItem.badgeValue = [NSString stringWithFormat:@"%d",unread.status];
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         
     }];


}



- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
    //删除系统自动生成的UITabBarButton
    for(UIView *child in self.tabBar.subviews){
        if([child isKindOfClass:[UIControl class]]){
            [child removeFromSuperview];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/**
 *  初始化TabBar
 */
- (void) setupTabBar
{
    MyTabBar *customTabBar = [[MyTabBar alloc]init];
    customTabBar.frame = self.tabBar.bounds;
    customTabBar.delegate = self;
    [self.tabBar addSubview:customTabBar];
    self.customTabBar = customTabBar;
}

#pragma mark - MyTabBar的代理方法
/**
 *  监听tabBar按钮的改变
 *
 *  @param from   原来选中的位置
 *  @param to     现在选中的位置
 */
- (void)tabBar:(MyTabBar *)tabBar didSelectedButtonFrom:(long)from To:(long)to
{
    self.selectedIndex = to;
}


/**
 *  监听加号按钮
 *
 */
- (void) tabBarDidClickPlusButton:(MyTabBar *)tabBar
{
    MyComposeViewController *compose = [[MyComposeViewController alloc]init];
    MyNavgationViewController *nav = [[MyNavgationViewController alloc]initWithRootViewController:compose];
    [self presentViewController:nav animated:YES completion:nil];
 
}


#pragma mark


/**
 *  初始化一个子控制器
 *
 *  @param childVC           需要初始化的子控制器
 *  @param title             标题
 *  @param imageName         图标
 *  @param selectedImageName 所中后图标
 */
- (void) setupChildViewController:(UIViewController *)childVC title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    //1.设置控制器属性
    childVC.title =title;
    //设置图标
    childVC.tabBarItem.image = [UIImage imageWithName:imageName];
    //设置选中图标
    if(iOS7){
        childVC.tabBarItem.selectedImage = [[UIImage imageWithName:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }else{
        childVC.tabBarItem.selectedImage = [UIImage imageWithName:selectedImageName];
    }
    
    //2.包装一个导航控制器
    MyNavgationViewController *nav = [[MyNavgationViewController alloc] initWithRootViewController:childVC];
    [self addChildViewController:nav];
    
    //3.添加TabBar内部的Button
    [self.customTabBar addTabBarButtonWithItem:childVC.tabBarItem];
    
}



/**
 *  初始化所有子控制器
 */
- (void) setupAllChildViewController
{
    //1.首页
    HomeViewController *home = [[HomeViewController alloc]init];
   // home.tabBarItem.badgeValue = @"99";   //设置右上角上面的文字
    [self setupChildViewController:home title:@"首页" imageName:@"tabbar_home" selectedImageName:@"tabbar_home_selected"];
    _home = home;
    
    //2.消息
    MessageViewController *message = [[MessageViewController alloc]init];
    [self setupChildViewController:message title:@"消息" imageName:@"tabbar_message_center" selectedImageName:@"tabbar_message_center_selected"];
    
    //3.广场
    DiscoverViewController *discover = [[DiscoverViewController alloc]init];
    [self setupChildViewController:discover title:@"广场" imageName:@"tabbar_discover" selectedImageName:@"tabbar_discover_selected"];
    
    //4.个人
    MeViewController *me =[[MeViewController alloc]init];
    [self setupChildViewController:me title:@"个人" imageName:@"tabbar_profile" selectedImageName:@"tabbar_profile_selected"];
}


















@end
