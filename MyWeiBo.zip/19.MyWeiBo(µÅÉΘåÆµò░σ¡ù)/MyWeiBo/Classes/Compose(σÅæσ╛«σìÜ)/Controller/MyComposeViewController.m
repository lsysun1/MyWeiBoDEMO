//
//  MyComposeViewController.m
//  MyWeiBo
//
//  Created by 李松玉 on 9/4/14.
//  Copyright (c) 2014 Sun1. All rights reserved.
//



/**
    UITextField     不能换行
    UITextView      没有提醒文字
 **/


#import "MyComposeViewController.h"
#import "MyTextView.h"
#import "AFNetworking.h"
#import "MyCommon.h"
#import "MyAccount.h"
#import "MyAccountTools.h"
#import "MBProgressHUD+MJ.h"


@interface MyComposeViewController() <UITextViewDelegate>
@property (nonatomic ,strong ) MyTextView *textView;
@end

@implementation MyComposeViewController


- (void)loadView{
    [super loadView];

    //  1.设置导航栏属性
    [self setupNavBar];

    
    //  2.添加textView
    [self setupTextView];
    
    
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_textView becomeFirstResponder];

}



- (void) setupNavBar
{
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(cancel)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(send)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    self.title = @"发微博";
}


- (void) setupTextView
{
    //  1.添加textView空间
    MyTextView *textView = [[MyTextView alloc]init];
    textView.alwaysBounceVertical = YES;
    textView.delegate = self;
    textView.font = [UIFont systemFontOfSize:15];
    textView.frame = self.view.bounds;
    textView.placehoder = @"请输入要发送的微博文字:";
    _textView = textView;
    [self.view addSubview:textView];

    
    /**
     *  2.监听textView文字的改变----->用通知的方法来实现
     *
     *  self在监听到textView发送名字为UITextViewTextDidChangeNotification的notification时，调用textDidChange的方法
     */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:textView];
    
    
}





//  监听文字的改变
- (void) textDidChange
{
    self.navigationItem.rightBarButtonItem.enabled = self.textView.text.length;
}


- (void)dealloc
{
    //移除监听
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



- (void) cancel{
    [self dismissViewControllerAnimated:YES completion:nil];

}

/**
 *  发送微博
 */
- (void) send{
    //  1.创建AFN请求管理对象
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    //  2.封装请求参数
    NSMutableDictionary *parms = [NSMutableDictionary dictionary];
    parms[@"status"] = self.textView.text;
    parms[@"access_token"] = [MyAccountTools GetAccount].access_token;
    
    //  3.发送请求
    [mgr POST:@"https://api.weibo.com/2/statuses/update.json" parameters:parms success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD showSuccess:@"发送成功!"];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"发送失败!"];
    }];

    
    //  4.关闭控制器,返回首页
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark UITextView 代理方法


- (void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}










@end
