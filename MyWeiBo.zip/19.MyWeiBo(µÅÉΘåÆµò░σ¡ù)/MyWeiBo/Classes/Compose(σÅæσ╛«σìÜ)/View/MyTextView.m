//
//  MyTextView.m
//  MyWeiBo
//
//  Created by 李松玉 on 9/4/14.
//  Copyright (c) 2014 Sun1. All rights reserved.
//

#import "MyTextView.h"


@interface MyTextView()
@property (nonatomic, weak) UILabel *placeLabel;
@end

@implementation MyTextView

- (id)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame]){
        
        UILabel *placeLabel = [[UILabel alloc]init];
        placeLabel.textColor = [UIColor lightGrayColor];
        placeLabel.hidden = NO;
        placeLabel.numberOfLines = 0;
        [self insertSubview:placeLabel atIndex:0];
        placeLabel.font = self.font;
        _placeLabel = placeLabel;
        
        
        //监听textView文字的改变的通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self];
    }

    return self;
}


- (void) setPlacehoder:(NSString *)placehoder
{
    _placehoder = [placehoder copy];

    self.placeLabel.text = placehoder;

    if(placehoder.length){
        self.placeLabel.hidden = NO;
        //计算placeLabel的Frame
        CGFloat placeholderX = 5;
        CGFloat placeholderY = 7;
        CGFloat maxW = self.frame.size.width - 2 * placeholderX;
        CGFloat maxH = self.frame.size.height - 2 * placeholderY;
        CGSize placeholderSize = [placehoder sizeWithFont:self.placeLabel.font constrainedToSize:CGSizeMake(maxW, maxH)];
        self.placeLabel.frame = CGRectMake(placeholderX, placeholderY, placeholderSize.width, placeholderSize.height);

    }else{
        self.placeLabel.hidden = YES;
    }
}

- (void) textDidChange
{
    self.placeLabel.hidden = (self.text.length != 0);
}

- (void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end
