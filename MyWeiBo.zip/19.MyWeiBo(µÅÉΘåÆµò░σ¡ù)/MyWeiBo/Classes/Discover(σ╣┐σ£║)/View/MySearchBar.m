//
//  MySearchBar.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/21.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//


#import "MySearchBar.h"

@interface MySearchBar()
@end



@implementation MySearchBar

+ (instancetype) searchBar
{
    return [[self alloc]init];
}



- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self){
        //  设置背景
        self.background = [UIImage resizeImageWithName:@"searchbar_textfield_background"];
        //  设置searchBar的左边的放大镜图标
        //  由于素材中没有searchbar_textfield_search_icon的IOS7版本，所以就是用了imageNamed方法
        UIImageView *iconView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"searchbar_textfield_search_icon"]];
        iconView.frame = CGRectMake(0, 0, 30, 30);
        iconView.contentMode = UIViewContentModeCenter;
        self.leftView = iconView;
        self.leftViewMode = UITextFieldViewModeAlways;

        self.font = [UIFont systemFontOfSize:13];
        //  设置提醒文字
        NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
        attrs[NSForegroundColorAttributeName] = [UIColor grayColor];
        self.attributedPlaceholder = [[NSAttributedString alloc]initWithString:@"搜索" attributes:attrs];
        //  设置右边的清除按钮
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
        
        //  设置键盘右下角按钮的样式
        self.returnKeyType = UIReturnKeySearch;
        self.enablesReturnKeyAutomatically = YES;
    
    }
    return self;
}





@end
