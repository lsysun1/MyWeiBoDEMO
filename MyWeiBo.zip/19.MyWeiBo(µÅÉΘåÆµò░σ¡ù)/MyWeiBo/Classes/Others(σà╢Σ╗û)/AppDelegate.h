//
//  AppDelegate.h
//  MyWeiBo
//
//  Created by 李松玉 on 14-7-10.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
