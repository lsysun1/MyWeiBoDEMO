//
//  MyCommon.h
//  MyWeiBo
//
//  Created by 李松玉 on 9/3/14.
//  Copyright (c) 2014 Sun1. All rights reserved.
//

#ifndef MyWeiBo_MyCommon_h
#define MyWeiBo_MyCommon_h


// 0.账号相关
#define MyAppKey @"2892042268"
#define MyAppSecret @"c5f8aa2b15281473f28b228034d1c228"
#define MyRedirectURL @"https://api.weibo.com/oauth2/default.html"
#define MyLoginURL [NSString stringWithFormat:@"https://api.weibo.com/oauth2/authorize?client_id=%@&redirect_uri=%@",MyAppKey,MyRedirectURL] 


// 1.判断是否是IOS
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0)

// 2.获得RGB颜色
#define MyColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

// 3.自定义Log
#ifdef DEBUG
#define MYLog(...) NSLog(__VA_ARGS__)
#else
#define MYLog(...)
#endif

// 4.判断是否是4英寸
#define is4Inch [UIScreen mainScreen].bounds.size.height == 568

/**  cell的边框高度  **/
#define MyStatueseCellBorder 10

/**  昵称的字体  **/
#define MyStatueseNameFont  [UIFont systemFontOfSize:15]

/**  被转发微博作者昵称的字体  **/
#define MyRepostStatueseNameFont  [UIFont systemFontOfSize:13]

/**  时间的字体  **/
#define MyStatueseTimeFont  [UIFont systemFontOfSize:10]

/**  来源的字体  **/
#define MyStatueseSourceFont  MyStatueseTimeFont

/**  正文的字体  **/
#define MyStatueseContentFont  [UIFont systemFontOfSize:15]

/**  被转发微博正文的字体  **/
#define MyRepostStatueseContentFont  [UIFont systemFontOfSize:13]

/** 表格的边框宽度 **/
#define MyStatusTableBorder 5






#endif
