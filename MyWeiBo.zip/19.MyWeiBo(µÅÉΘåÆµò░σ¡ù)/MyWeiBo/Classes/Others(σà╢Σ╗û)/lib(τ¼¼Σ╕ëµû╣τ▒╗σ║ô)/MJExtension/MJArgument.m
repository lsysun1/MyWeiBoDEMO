//
//  MJArgument.m
//  ItcastWeibo
//
//  Created by mj on 14-1-15.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "MJArgument.h"
#import "MJExtension.h"

@implementation MJArgument
MJLogAllIvrs
@end
