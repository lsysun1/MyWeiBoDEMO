//
//  MyWeiBoTools.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/22.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//  微博项目的工具类

#import <Foundation/Foundation.h>

@interface MyWeiBoTools : NSObject



/**
 *  根据是否是第一次使用软件来选择根控制器
 */
+(void)chooseRootController;



@end
