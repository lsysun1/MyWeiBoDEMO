//
//  UIImage+My.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/19.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "UIImage+My.h"

@implementation UIImage (My)


+ (UIImage *) imageWithName:(NSString *)name
{
    if(iOS7)
    {
        NSString *newName = [name stringByAppendingString:@"_os7"];
        UIImage *image = [UIImage imageNamed:newName];
        if(image == nil)    // 没有_os7后缀的图片
        {
            image = [UIImage imageNamed:name];
        }
        return image;
    }
    
    //非ios7
    return [UIImage imageNamed:name];
}




+ (UIImage *) resizeImageWithName:(NSString *)name
{
    return [self resizeImageWithName:name left:0.5 top:0.5];
}

+ (UIImage *) resizeImageWithName:(NSString *)name left:(CGFloat)left top:(CGFloat)top
{
    UIImage *image = [self imageWithName:name];
    return [image stretchableImageWithLeftCapWidth:image.size.width * left  topCapHeight:image.size.height * top];
}

@end
