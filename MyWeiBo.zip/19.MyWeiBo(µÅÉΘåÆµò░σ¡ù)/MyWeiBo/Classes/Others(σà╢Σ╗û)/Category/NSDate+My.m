//
//  NSDate+My.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/28.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "NSDate+My.h"

@implementation NSDate (My)
- (BOOL)isToday
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    int unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    
    //获得当前时间的年月日
    NSDateComponents *nowComps = [calendar components:unit fromDate:[NSDate date]];
    
    //获得self时间的年月日
    NSDateComponents *selfComps = [calendar components:unit fromDate:self];
    
    return  (nowComps.year == selfComps.year) &&
            (nowComps.month == selfComps.month) &&
            (nowComps.day == selfComps.day);
}



- (BOOL)isYeaterday
{
    NSDate *now = [NSDate date];
    NSDateFormatter *fmt = [[NSDateFormatter alloc]init];
    fmt.dateFormat = @"YYYY-MM-dd";

    NSString *nowStr = [fmt stringFromDate:now];
    NSDate *nowDate = [fmt dateFromString:nowStr];
    
    NSString *selfStr = [fmt stringFromDate:self];
    NSDate *selfDate = [fmt dateFromString:selfStr];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *cmps = [calendar components:NSCalendarCalendarUnit fromDate:selfDate toDate:nowDate options:1];
    return cmps.day == 1;
}

- (BOOL)isThisYear
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    int unit = NSCalendarUnitYear;
    
    //获得当前时间的年
    NSDateComponents *nowComps = [calendar components:unit fromDate:[NSDate date]];
    
    //获得self时间的年
    NSDateComponents *selfComps = [calendar components:unit fromDate:self];
    
    return nowComps.year == selfComps.year;
}


- (NSDateComponents *) deltaWithNow
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    int unit = NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    return [calendar components:unit fromDate:self toDate:[NSDate date] options:0];
}















@end
