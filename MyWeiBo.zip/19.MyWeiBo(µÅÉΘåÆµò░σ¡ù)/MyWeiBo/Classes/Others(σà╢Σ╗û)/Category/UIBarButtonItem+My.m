//
//  UIBarButtonItem+My.m
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/21.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import "UIBarButtonItem+My.h"

@implementation UIBarButtonItem (My)


+ (UIBarButtonItem *) target:(id)target itemWithIcon:(NSString *)icon HighIcon:(NSString *)HighIcon action:(SEL)action
{
    UIButton *Button = [UIButton buttonWithType:UIButtonTypeCustom];
    [Button setBackgroundImage:[UIImage imageWithName:icon] forState:UIControlStateNormal];
    [Button setBackgroundImage:[UIImage imageWithName:HighIcon] forState:UIControlStateHighlighted];
    Button.frame = CGRectMake(0, 0, Button.currentBackgroundImage.size.width, Button.currentBackgroundImage.size.height);
    [Button addTarget:target action:action forControlEvents:UIControlEventTouchDragInside];
    return [[UIBarButtonItem alloc]initWithCustomView:Button];
}



@end
