//
//  NSDate+My.h
//  MyWeiBo
//
//  Created by 李松玉 on 14/8/28.
//  Copyright (c) 2014年 Sun1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (My)

- (BOOL)isToday;

- (BOOL)isYeaterday;

- (BOOL)isThisYear;


/**
 *  获得self与当前时间的差距的Components
 *
 */
- (NSDateComponents *) deltaWithNow;

@end
